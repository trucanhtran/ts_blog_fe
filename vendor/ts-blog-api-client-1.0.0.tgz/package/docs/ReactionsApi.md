# ReactionsApi

All URIs are relative to *http://localhost*

|Method | HTTP request | Description|
|------------- | ------------- | -------------|
|[**apiV1ReactionsGet**](#apiv1reactionsget) | **GET** /api/v1/reactions | List reactions|
|[**apiV1ReactionsIdDelete**](#apiv1reactionsiddelete) | **DELETE** /api/v1/reactions/{id} | Delete reaction|
|[**apiV1ReactionsIdGet**](#apiv1reactionsidget) | **GET** /api/v1/reactions/{id} | Show reaction|
|[**apiV1ReactionsIdPatch**](#apiv1reactionsidpatch) | **PATCH** /api/v1/reactions/{id} | Update reaction|
|[**apiV1ReactionsIdPut**](#apiv1reactionsidput) | **PUT** /api/v1/reactions/{id} | Update reaction (full update)|
|[**apiV1ReactionsPost**](#apiv1reactionspost) | **POST** /api/v1/reactions | Create reaction|

# **apiV1ReactionsGet**
> ApiV1ReactionsGet200Response apiV1ReactionsGet()


### Example

```typescript
import {
    ReactionsApi,
    Configuration
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new ReactionsApi(configuration);

let page: number; // (optional) (default to undefined)
let perPage: number; // (optional) (default to undefined)

const { status, data } = await apiInstance.apiV1ReactionsGet(
    page,
    perPage
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **page** | [**number**] |  | (optional) defaults to undefined|
| **perPage** | [**number**] |  | (optional) defaults to undefined|


### Return type

**ApiV1ReactionsGet200Response**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1ReactionsIdDelete**
> apiV1ReactionsIdDelete()


### Example

```typescript
import {
    ReactionsApi,
    Configuration
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new ReactionsApi(configuration);

let id: number; // (default to undefined)

const { status, data } = await apiInstance.apiV1ReactionsIdDelete(
    id
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **id** | [**number**] |  | defaults to undefined|


### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**204** | deleted |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1ReactionsIdGet**
> Reaction apiV1ReactionsIdGet()


### Example

```typescript
import {
    ReactionsApi,
    Configuration
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new ReactionsApi(configuration);

let id: number; // (default to undefined)

const { status, data } = await apiInstance.apiV1ReactionsIdGet(
    id
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **id** | [**number**] |  | defaults to undefined|


### Return type

**Reaction**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | success |  -  |
|**404** | Reaction not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1ReactionsIdPatch**
> Reaction apiV1ReactionsIdPatch(apiV1ReactionsPostRequest)


### Example

```typescript
import {
    ReactionsApi,
    Configuration,
    ApiV1ReactionsPostRequest
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new ReactionsApi(configuration);

let id: number; // (default to undefined)
let apiV1ReactionsPostRequest: ApiV1ReactionsPostRequest; //

const { status, data } = await apiInstance.apiV1ReactionsIdPatch(
    id,
    apiV1ReactionsPostRequest
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **apiV1ReactionsPostRequest** | **ApiV1ReactionsPostRequest**|  | |
| **id** | [**number**] |  | defaults to undefined|


### Return type

**Reaction**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | updated |  -  |
|**422** | Validation error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1ReactionsIdPut**
> Reaction apiV1ReactionsIdPut(reactionInput)


### Example

```typescript
import {
    ReactionsApi,
    Configuration,
    ReactionInput
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new ReactionsApi(configuration);

let id: number; // (default to undefined)
let reactionInput: ReactionInput; //

const { status, data } = await apiInstance.apiV1ReactionsIdPut(
    id,
    reactionInput
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **reactionInput** | **ReactionInput**|  | |
| **id** | [**number**] |  | defaults to undefined|


### Return type

**Reaction**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | updated |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1ReactionsPost**
> Reaction apiV1ReactionsPost(apiV1ReactionsPostRequest)


### Example

```typescript
import {
    ReactionsApi,
    Configuration,
    ApiV1ReactionsPostRequest
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new ReactionsApi(configuration);

let apiV1ReactionsPostRequest: ApiV1ReactionsPostRequest; //

const { status, data } = await apiInstance.apiV1ReactionsPost(
    apiV1ReactionsPostRequest
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **apiV1ReactionsPostRequest** | **ApiV1ReactionsPostRequest**|  | |


### Return type

**Reaction**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**201** | created |  -  |
|**422** | Validation error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

