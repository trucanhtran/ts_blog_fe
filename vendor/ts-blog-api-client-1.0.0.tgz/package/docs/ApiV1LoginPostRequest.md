# ApiV1LoginPostRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user** | [**ApiV1LoginPostRequestUser**](ApiV1LoginPostRequestUser.md) |  | [default to undefined]

## Example

```typescript
import { ApiV1LoginPostRequest } from '@ts-blog/api-client';

const instance: ApiV1LoginPostRequest = {
    user,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
