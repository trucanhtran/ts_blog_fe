# ApiV1PostsGet200ResponseMeta


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**page** | **number** |  | [optional] [default to undefined]
**per_page** | **number** |  | [optional] [default to undefined]
**total** | **number** |  | [optional] [default to undefined]

## Example

```typescript
import { ApiV1PostsGet200ResponseMeta } from '@ts-blog/api-client';

const instance: ApiV1PostsGet200ResponseMeta = {
    page,
    per_page,
    total,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
