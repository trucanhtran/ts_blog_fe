# CommentsApi

All URIs are relative to *http://localhost*

|Method | HTTP request | Description|
|------------- | ------------- | -------------|
|[**apiV1CommentsGet**](#apiv1commentsget) | **GET** /api/v1/comments | Get list of comments|
|[**apiV1CommentsIdDelete**](#apiv1commentsiddelete) | **DELETE** /api/v1/comments/{id} | Delete a comment|
|[**apiV1CommentsIdGet**](#apiv1commentsidget) | **GET** /api/v1/comments/{id} | Get comment by ID|
|[**apiV1CommentsIdPatch**](#apiv1commentsidpatch) | **PATCH** /api/v1/comments/{id} | Update a comment|
|[**apiV1CommentsIdPut**](#apiv1commentsidput) | **PUT** /api/v1/comments/{id} | Update a comment (full update)|
|[**apiV1CommentsPost**](#apiv1commentspost) | **POST** /api/v1/comments | Create a comment|

# **apiV1CommentsGet**
> ApiV1CommentsGet200Response apiV1CommentsGet()


### Example

```typescript
import {
    CommentsApi,
    Configuration
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new CommentsApi(configuration);

let perPage: number; //Number of comments per page (optional) (default to undefined)

const { status, data } = await apiInstance.apiV1CommentsGet(
    perPage
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **perPage** | [**number**] | Number of comments per page | (optional) defaults to undefined|


### Return type

**ApiV1CommentsGet200Response**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | List comments |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1CommentsIdDelete**
> apiV1CommentsIdDelete()


### Example

```typescript
import {
    CommentsApi,
    Configuration
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new CommentsApi(configuration);

let id: number; // (default to undefined)

const { status, data } = await apiInstance.apiV1CommentsIdDelete(
    id
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **id** | [**number**] |  | defaults to undefined|


### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**204** | Comment deleted |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1CommentsIdGet**
> Comment apiV1CommentsIdGet()


### Example

```typescript
import {
    CommentsApi,
    Configuration
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new CommentsApi(configuration);

let id: number; // (default to undefined)

const { status, data } = await apiInstance.apiV1CommentsIdGet(
    id
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **id** | [**number**] |  | defaults to undefined|


### Return type

**Comment**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | Comment detail |  -  |
|**404** | Comment not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1CommentsIdPatch**
> Comment apiV1CommentsIdPatch(apiV1CommentsIdPatchRequest)


### Example

```typescript
import {
    CommentsApi,
    Configuration,
    ApiV1CommentsIdPatchRequest
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new CommentsApi(configuration);

let id: number; // (default to undefined)
let apiV1CommentsIdPatchRequest: ApiV1CommentsIdPatchRequest; //

const { status, data } = await apiInstance.apiV1CommentsIdPatch(
    id,
    apiV1CommentsIdPatchRequest
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **apiV1CommentsIdPatchRequest** | **ApiV1CommentsIdPatchRequest**|  | |
| **id** | [**number**] |  | defaults to undefined|


### Return type

**Comment**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | Comment updated |  -  |
|**422** | Validation error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1CommentsIdPut**
> apiV1CommentsIdPut(commentInput)


### Example

```typescript
import {
    CommentsApi,
    Configuration,
    CommentInput
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new CommentsApi(configuration);

let id: number; // (default to undefined)
let commentInput: CommentInput; //

const { status, data } = await apiInstance.apiV1CommentsIdPut(
    id,
    commentInput
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **commentInput** | **CommentInput**|  | |
| **id** | [**number**] |  | defaults to undefined|


### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | Comment updated |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1CommentsPost**
> Comment apiV1CommentsPost(apiV1CommentsPostRequest)


### Example

```typescript
import {
    CommentsApi,
    Configuration,
    ApiV1CommentsPostRequest
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new CommentsApi(configuration);

let apiV1CommentsPostRequest: ApiV1CommentsPostRequest; //

const { status, data } = await apiInstance.apiV1CommentsPost(
    apiV1CommentsPostRequest
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **apiV1CommentsPostRequest** | **ApiV1CommentsPostRequest**|  | |


### Return type

**Comment**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**201** | Comment created |  -  |
|**422** | Validation error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

