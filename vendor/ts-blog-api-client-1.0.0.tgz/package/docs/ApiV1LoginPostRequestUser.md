# ApiV1LoginPostRequestUser


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** |  | [default to undefined]
**password** | **string** |  | [default to undefined]

## Example

```typescript
import { ApiV1LoginPostRequestUser } from '@ts-blog/api-client';

const instance: ApiV1LoginPostRequestUser = {
    email,
    password,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
