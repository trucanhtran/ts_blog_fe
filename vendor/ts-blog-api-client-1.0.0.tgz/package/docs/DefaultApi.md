# DefaultApi

All URIs are relative to *http://localhost*

|Method | HTTP request | Description|
|------------- | ------------- | -------------|
|[**apiV1PostsGet**](#apiv1postsget) | **GET** /api/v1/posts | List posts|
|[**apiV1PostsIdDelete**](#apiv1postsiddelete) | **DELETE** /api/v1/posts/{id} | Delete post|
|[**apiV1PostsIdGet**](#apiv1postsidget) | **GET** /api/v1/posts/{id} | Show post|
|[**apiV1PostsIdPatch**](#apiv1postsidpatch) | **PATCH** /api/v1/posts/{id} | Update post|
|[**apiV1PostsPost**](#apiv1postspost) | **POST** /api/v1/posts | Create post|

# **apiV1PostsGet**
> ApiV1PostsGet200Response apiV1PostsGet()


### Example

```typescript
import {
    DefaultApi,
    Configuration
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new DefaultApi(configuration);

let page: number; // (optional) (default to undefined)
let perPage: number; // (optional) (default to undefined)

const { status, data } = await apiInstance.apiV1PostsGet(
    page,
    perPage
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **page** | [**number**] |  | (optional) defaults to undefined|
| **perPage** | [**number**] |  | (optional) defaults to undefined|


### Return type

**ApiV1PostsGet200Response**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1PostsIdDelete**
> apiV1PostsIdDelete()


### Example

```typescript
import {
    DefaultApi,
    Configuration
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new DefaultApi(configuration);

let id: number; // (default to undefined)

const { status, data } = await apiInstance.apiV1PostsIdDelete(
    id
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **id** | [**number**] |  | defaults to undefined|


### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**204** | deleted |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1PostsIdGet**
> Post apiV1PostsIdGet()


### Example

```typescript
import {
    DefaultApi,
    Configuration
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new DefaultApi(configuration);

let id: number; // (default to undefined)

const { status, data } = await apiInstance.apiV1PostsIdGet(
    id
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **id** | [**number**] |  | defaults to undefined|


### Return type

**Post**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | success |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1PostsIdPatch**
> Post apiV1PostsIdPatch(apiV1PostsPostRequest)


### Example

```typescript
import {
    DefaultApi,
    Configuration,
    ApiV1PostsPostRequest
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new DefaultApi(configuration);

let id: number; // (default to undefined)
let apiV1PostsPostRequest: ApiV1PostsPostRequest; //

const { status, data } = await apiInstance.apiV1PostsIdPatch(
    id,
    apiV1PostsPostRequest
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **apiV1PostsPostRequest** | **ApiV1PostsPostRequest**|  | |
| **id** | [**number**] |  | defaults to undefined|


### Return type

**Post**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | updated |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1PostsPost**
> Post apiV1PostsPost(apiV1PostsPostRequest)


### Example

```typescript
import {
    DefaultApi,
    Configuration,
    ApiV1PostsPostRequest
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new DefaultApi(configuration);

let apiV1PostsPostRequest: ApiV1PostsPostRequest; //

const { status, data } = await apiInstance.apiV1PostsPost(
    apiV1PostsPostRequest
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **apiV1PostsPostRequest** | **ApiV1PostsPostRequest**|  | |


### Return type

**Post**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**201** | created |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

