# ReactionInput


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kind** | **string** |  | [default to undefined]
**user_id** | **number** |  | [default to undefined]
**reactionable_type** | **string** |  | [default to undefined]
**reactionable_id** | **number** |  | [default to undefined]

## Example

```typescript
import { ReactionInput } from '@ts-blog/api-client';

const instance: ReactionInput = {
    kind,
    user_id,
    reactionable_type,
    reactionable_id,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
