# ApiV1SignupPostRequestUser


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** |  | [default to undefined]
**name** | **string** |  | [default to undefined]
**password** | **string** |  | [default to undefined]
**password_confirmation** | **string** |  | [default to undefined]

## Example

```typescript
import { ApiV1SignupPostRequestUser } from '@ts-blog/api-client';

const instance: ApiV1SignupPostRequestUser = {
    email,
    name,
    password,
    password_confirmation,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
