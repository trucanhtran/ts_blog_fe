# AuthenticationApi

All URIs are relative to *http://localhost*

|Method | HTTP request | Description|
|------------- | ------------- | -------------|
|[**apiV1LoginPost**](#apiv1loginpost) | **POST** /api/v1/login | Login user|
|[**apiV1SignupPost**](#apiv1signuppost) | **POST** /api/v1/signup | User signup|

# **apiV1LoginPost**
> AuthResponse apiV1LoginPost(apiV1LoginPostRequest)


### Example

```typescript
import {
    AuthenticationApi,
    Configuration,
    ApiV1LoginPostRequest
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new AuthenticationApi(configuration);

let apiV1LoginPostRequest: ApiV1LoginPostRequest; //

const { status, data } = await apiInstance.apiV1LoginPost(
    apiV1LoginPostRequest
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **apiV1LoginPostRequest** | **ApiV1LoginPostRequest**|  | |


### Return type

**AuthResponse**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**200** | Logged in successfully |  -  |
|**401** | Invalid email or password |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiV1SignupPost**
> AuthResponse apiV1SignupPost(apiV1SignupPostRequest)


### Example

```typescript
import {
    AuthenticationApi,
    Configuration,
    ApiV1SignupPostRequest
} from '@ts-blog/api-client';

const configuration = new Configuration();
const apiInstance = new AuthenticationApi(configuration);

let apiV1SignupPostRequest: ApiV1SignupPostRequest; //

const { status, data } = await apiInstance.apiV1SignupPost(
    apiV1SignupPostRequest
);
```

### Parameters

|Name | Type | Description  | Notes|
|------------- | ------------- | ------------- | -------------|
| **apiV1SignupPostRequest** | **ApiV1SignupPostRequest**|  | |


### Return type

**AuthResponse**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
|**201** | Signed up successfully |  -  |
|**422** | Validation error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

