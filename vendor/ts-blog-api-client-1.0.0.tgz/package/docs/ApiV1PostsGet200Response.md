# ApiV1PostsGet200Response


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**Array&lt;Post&gt;**](Post.md) |  | [optional] [default to undefined]
**meta** | [**ApiV1PostsGet200ResponseMeta**](ApiV1PostsGet200ResponseMeta.md) |  | [optional] [default to undefined]

## Example

```typescript
import { ApiV1PostsGet200Response } from '@ts-blog/api-client';

const instance: ApiV1PostsGet200Response = {
    data,
    meta,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
