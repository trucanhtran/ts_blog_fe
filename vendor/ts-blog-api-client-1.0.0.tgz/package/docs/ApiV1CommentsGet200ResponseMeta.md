# ApiV1CommentsGet200ResponseMeta


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**current_page** | **number** |  | [optional] [default to undefined]
**total_pages** | **number** |  | [optional] [default to undefined]
**total_count** | **number** |  | [optional] [default to undefined]

## Example

```typescript
import { ApiV1CommentsGet200ResponseMeta } from '@ts-blog/api-client';

const instance: ApiV1CommentsGet200ResponseMeta = {
    current_page,
    total_pages,
    total_count,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
