# CommentInput


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | **string** |  | [default to undefined]
**post_id** | **number** |  | [default to undefined]
**user_id** | **number** |  | [default to undefined]

## Example

```typescript
import { CommentInput } from '@ts-blog/api-client';

const instance: CommentInput = {
    content,
    post_id,
    user_id,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
