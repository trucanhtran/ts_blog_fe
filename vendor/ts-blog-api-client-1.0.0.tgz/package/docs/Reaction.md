# Reaction


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **number** |  | [optional] [default to undefined]
**kind** | **string** |  | [default to undefined]
**user** | [**User**](User.md) |  | [default to undefined]
**reactionable_type** | **string** |  | [default to undefined]
**reactionable_id** | **number** |  | [default to undefined]
**created_at** | **string** |  | [optional] [default to undefined]
**updated_at** | **string** |  | [optional] [default to undefined]

## Example

```typescript
import { Reaction } from '@ts-blog/api-client';

const instance: Reaction = {
    id,
    kind,
    user,
    reactionable_type,
    reactionable_id,
    created_at,
    updated_at,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
