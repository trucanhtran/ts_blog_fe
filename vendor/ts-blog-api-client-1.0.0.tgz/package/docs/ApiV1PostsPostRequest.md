# ApiV1PostsPostRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**post** | [**PostInput**](PostInput.md) |  | [optional] [default to undefined]

## Example

```typescript
import { ApiV1PostsPostRequest } from '@ts-blog/api-client';

const instance: ApiV1PostsPostRequest = {
    post,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
