# ApiV1LoginPost401Response


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **string** |  | [optional] [default to undefined]

## Example

```typescript
import { ApiV1LoginPost401Response } from '@ts-blog/api-client';

const instance: ApiV1LoginPost401Response = {
    error,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
