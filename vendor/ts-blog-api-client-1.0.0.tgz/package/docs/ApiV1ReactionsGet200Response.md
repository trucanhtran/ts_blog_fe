# ApiV1ReactionsGet200Response


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**Array&lt;Reaction&gt;**](Reaction.md) |  | [optional] [default to undefined]
**meta** | [**ApiV1PostsGet200ResponseMeta**](ApiV1PostsGet200ResponseMeta.md) |  | [optional] [default to undefined]

## Example

```typescript
import { ApiV1ReactionsGet200Response } from '@ts-blog/api-client';

const instance: ApiV1ReactionsGet200Response = {
    data,
    meta,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
