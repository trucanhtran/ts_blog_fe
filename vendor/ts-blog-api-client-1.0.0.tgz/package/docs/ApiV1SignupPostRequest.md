# ApiV1SignupPostRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user** | [**ApiV1SignupPostRequestUser**](ApiV1SignupPostRequestUser.md) |  | [optional] [default to undefined]

## Example

```typescript
import { ApiV1SignupPostRequest } from '@ts-blog/api-client';

const instance: ApiV1SignupPostRequest = {
    user,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
