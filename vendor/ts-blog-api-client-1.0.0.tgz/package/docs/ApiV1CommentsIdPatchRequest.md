# ApiV1CommentsIdPatchRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | **string** |  | [optional] [default to undefined]
**post_id** | **number** |  | [optional] [default to undefined]
**user_id** | **number** |  | [optional] [default to undefined]

## Example

```typescript
import { ApiV1CommentsIdPatchRequest } from '@ts-blog/api-client';

const instance: ApiV1CommentsIdPatchRequest = {
    content,
    post_id,
    user_id,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
