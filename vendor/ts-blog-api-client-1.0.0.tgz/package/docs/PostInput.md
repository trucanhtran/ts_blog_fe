# PostInput


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** |  | [default to undefined]
**content** | **string** |  | [default to undefined]
**published** | **boolean** |  | [optional] [default to undefined]
**author_id** | **number** |  | [default to undefined]
**summary** | **string** |  | [optional] [default to undefined]

## Example

```typescript
import { PostInput } from '@ts-blog/api-client';

const instance: PostInput = {
    title,
    content,
    published,
    author_id,
    summary,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
