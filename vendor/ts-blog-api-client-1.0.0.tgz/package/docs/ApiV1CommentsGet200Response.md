# ApiV1CommentsGet200Response


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**Array&lt;Comment&gt;**](Comment.md) |  | [optional] [default to undefined]
**meta** | [**ApiV1CommentsGet200ResponseMeta**](ApiV1CommentsGet200ResponseMeta.md) |  | [optional] [default to undefined]

## Example

```typescript
import { ApiV1CommentsGet200Response } from '@ts-blog/api-client';

const instance: ApiV1CommentsGet200Response = {
    data,
    meta,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
