# ApiV1ReactionsPostRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reaction** | [**ReactionInput**](ReactionInput.md) |  | [optional] [default to undefined]

## Example

```typescript
import { ApiV1ReactionsPostRequest } from '@ts-blog/api-client';

const instance: ApiV1ReactionsPostRequest = {
    reaction,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
