## @ts-blog/api-client@1.0.0

This generator creates TypeScript/JavaScript client that utilizes [axios](https://github.com/axios/axios). The generated Node module can be used in the following environments:

Environment
* Node.js
* Webpack
* Browserify

Language level
* ES5 - you must have a Promises/A+ library installed
* ES6

Module system
* CommonJS
* ES6 module system

It can be used in both TypeScript and JavaScript. In TypeScript, the definition will be automatically resolved via `package.json`. ([Reference](https://www.typescriptlang.org/docs/handbook/declaration-files/consumption.html))

### Building

To build and compile the typescript sources to javascript use:
```
npm install
npm run build
```

### Publishing

First build the package then run `npm publish`

### Consuming

navigate to the folder of your consuming project and run one of the following commands.

_published:_

```
npm install @ts-blog/api-client@1.0.0 --save
```

_unPublished (not recommended):_

```
npm install PATH_TO_GENERATED_PACKAGE --save
```

### Documentation for API Endpoints

All URIs are relative to *http://localhost*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AuthenticationApi* | [**apiV1LoginPost**](docs/AuthenticationApi.md#apiv1loginpost) | **POST** /api/v1/login | Login user
*AuthenticationApi* | [**apiV1SignupPost**](docs/AuthenticationApi.md#apiv1signuppost) | **POST** /api/v1/signup | User signup
*CommentsApi* | [**apiV1CommentsGet**](docs/CommentsApi.md#apiv1commentsget) | **GET** /api/v1/comments | Get list of comments
*CommentsApi* | [**apiV1CommentsIdDelete**](docs/CommentsApi.md#apiv1commentsiddelete) | **DELETE** /api/v1/comments/{id} | Delete a comment
*CommentsApi* | [**apiV1CommentsIdGet**](docs/CommentsApi.md#apiv1commentsidget) | **GET** /api/v1/comments/{id} | Get comment by ID
*CommentsApi* | [**apiV1CommentsIdPatch**](docs/CommentsApi.md#apiv1commentsidpatch) | **PATCH** /api/v1/comments/{id} | Update a comment
*CommentsApi* | [**apiV1CommentsIdPut**](docs/CommentsApi.md#apiv1commentsidput) | **PUT** /api/v1/comments/{id} | Update a comment (full update)
*CommentsApi* | [**apiV1CommentsPost**](docs/CommentsApi.md#apiv1commentspost) | **POST** /api/v1/comments | Create a comment
*DefaultApi* | [**apiV1PostsGet**](docs/DefaultApi.md#apiv1postsget) | **GET** /api/v1/posts | List posts
*DefaultApi* | [**apiV1PostsIdDelete**](docs/DefaultApi.md#apiv1postsiddelete) | **DELETE** /api/v1/posts/{id} | Delete post
*DefaultApi* | [**apiV1PostsIdGet**](docs/DefaultApi.md#apiv1postsidget) | **GET** /api/v1/posts/{id} | Show post
*DefaultApi* | [**apiV1PostsIdPatch**](docs/DefaultApi.md#apiv1postsidpatch) | **PATCH** /api/v1/posts/{id} | Update post
*DefaultApi* | [**apiV1PostsPost**](docs/DefaultApi.md#apiv1postspost) | **POST** /api/v1/posts | Create post
*ReactionsApi* | [**apiV1ReactionsGet**](docs/ReactionsApi.md#apiv1reactionsget) | **GET** /api/v1/reactions | List reactions
*ReactionsApi* | [**apiV1ReactionsIdDelete**](docs/ReactionsApi.md#apiv1reactionsiddelete) | **DELETE** /api/v1/reactions/{id} | Delete reaction
*ReactionsApi* | [**apiV1ReactionsIdGet**](docs/ReactionsApi.md#apiv1reactionsidget) | **GET** /api/v1/reactions/{id} | Show reaction
*ReactionsApi* | [**apiV1ReactionsIdPatch**](docs/ReactionsApi.md#apiv1reactionsidpatch) | **PATCH** /api/v1/reactions/{id} | Update reaction
*ReactionsApi* | [**apiV1ReactionsIdPut**](docs/ReactionsApi.md#apiv1reactionsidput) | **PUT** /api/v1/reactions/{id} | Update reaction (full update)
*ReactionsApi* | [**apiV1ReactionsPost**](docs/ReactionsApi.md#apiv1reactionspost) | **POST** /api/v1/reactions | Create reaction


### Documentation For Models

 - [ApiV1CommentsGet200Response](docs/ApiV1CommentsGet200Response.md)
 - [ApiV1CommentsGet200ResponseMeta](docs/ApiV1CommentsGet200ResponseMeta.md)
 - [ApiV1CommentsIdPatchRequest](docs/ApiV1CommentsIdPatchRequest.md)
 - [ApiV1CommentsPostRequest](docs/ApiV1CommentsPostRequest.md)
 - [ApiV1LoginPost401Response](docs/ApiV1LoginPost401Response.md)
 - [ApiV1LoginPostRequest](docs/ApiV1LoginPostRequest.md)
 - [ApiV1LoginPostRequestUser](docs/ApiV1LoginPostRequestUser.md)
 - [ApiV1PostsGet200Response](docs/ApiV1PostsGet200Response.md)
 - [ApiV1PostsGet200ResponseMeta](docs/ApiV1PostsGet200ResponseMeta.md)
 - [ApiV1PostsPostRequest](docs/ApiV1PostsPostRequest.md)
 - [ApiV1ReactionsGet200Response](docs/ApiV1ReactionsGet200Response.md)
 - [ApiV1ReactionsPostRequest](docs/ApiV1ReactionsPostRequest.md)
 - [ApiV1SignupPostRequest](docs/ApiV1SignupPostRequest.md)
 - [ApiV1SignupPostRequestUser](docs/ApiV1SignupPostRequestUser.md)
 - [AuthResponse](docs/AuthResponse.md)
 - [Comment](docs/Comment.md)
 - [CommentInput](docs/CommentInput.md)
 - [Post](docs/Post.md)
 - [PostInput](docs/PostInput.md)
 - [Reaction](docs/Reaction.md)
 - [ReactionInput](docs/ReactionInput.md)
 - [User](docs/User.md)


<a id="documentation-for-authorization"></a>
## Documentation For Authorization

Endpoints do not require authorization.

